import os
from os.path import join
searchDir = raw_input('In which dir do you want search the Files? ')
fileExt = raw_input('What is the extension of that file?')
for (dirname, dirs, files) in os.walk(searchDir):
   for filename in files:
       if filename.endswith(fileExt):
           thefile = os.path.join(dirname,filename)
           print os.path.getsize(thefile), "  -  " , thefile
print "Welcome To"
# This is the Line Comment

print "Rns Python Programming"
''' This is Example for Multi
Line 
Comment
'''

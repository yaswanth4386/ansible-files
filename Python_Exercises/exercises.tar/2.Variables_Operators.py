#Floor division: Returns the value as an integer and throws away the decimals.
print "Floor division: ", 841.1//4
#Modulus: Returns just the remainder.
print "Modulus: ", 841 % 4
#Exponent:
print "Exponent : ", 2**4
#Number precision, using round:
print "Round Value of 1000/65 = ", round(1000 / 65, 4)
#Comparisons:
# greater than
print "1 is Greater than 2:  ", 1 > 2
# less than
print "600 is Less than 5:  ", 600<5
# less than or equal to
print "10 is lessthan or equal to 20 : ", 10<=20
# equal to
print "2 is equal 2 : ", 2==2
# complex
print "Complex Example : ",  1 <= 2 <= 4
#Minimum number from a list of numbers:
print "Min Number from the List : ", min(1,5,2,5,300,.03)
# Maximum number from a list of numbers:
print "Max Number from the List : ", max(1,5,2,5,300,.03)
